import javax.swing.JOptionPane;

import org.omg.Messaging.SyncScopeHelper;

public class Media {
public static void main(String[] args) {
	double soma =0;
	int cont = 1 ;
	double media;
	int qtdnumber = Integer.parseInt(JOptionPane.showInputDialog("Digite o tamanho do vetor:"));
	
	do{
	int number = Integer.parseInt(JOptionPane.showInputDialog("Digite um n�mero:"));
	
	soma = soma + number;
	cont ++;
	}while(cont <= qtdnumber);
	media = soma/qtdnumber;
	System.out.println("M�dia ="+ media);
	}
}

