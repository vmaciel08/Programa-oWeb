import java.util.Scanner;

import javax.swing.JOptionPane;

public class Goldbach {
	 public static void main(String[] args) {

	        Scanner e = new Scanner(System.in);

	        int a, b;

	        int n;

	        int cont=0;

	        System.out.println("Digite um n�mero par:");

	        n = e.nextInt();
	
	           
		for (a = 2; a <= n-2; a++) {
		    b = n - a;
		    //Aqui ele arredonda a raiz quadrada de a
		    long sqt = Math.round(Math.sqrt(a)); 

		   //Aqui verifica se a � primo;
		    for (int i = 1; i <= sqt; i++) {
		        if (a % i == 0) {
		            cont++;
		        }
		    }

		    if (cont == 1) { 
		        cont = 0; 
		        //Faz o mesmo processo com b
		        sqt = Math.round(Math.sqrt(b));
		        for (int i1 = 1; i1 <= sqt; i1++) {
		            if (b % i1 == 0) { 
		                cont++;
		            }
		        } if (cont == 1) { 
		            System.out.println("Sa�da:"+a + "+" + b);
		            //Quebra  o loop ao achar a resposta;
		            break;
		        }
		    }
		    cont = 0;
		}
	 }
}