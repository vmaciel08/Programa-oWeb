import java.util.Scanner;

public class Kaprekar {
	 public static boolean Kaprekar(long n0)
	    {
	        long izq=n0*n0, der=0, decimal=1;
	        boolean resultado=false; 
	        while(izq>0 && !resultado) 
	        {
	            der=der+izq%10*decimal; 
	            izq=izq/10;
	            decimal=decimal*10;
	            resultado=der>0 && izq+der==n0; 
	                                     
	        }
	        return resultado;
	    }
	    

	    public static void main(String[] args)
	    {
	        Scanner scan =new Scanner(System.in);
	        long n;
	        do
	        {
	            n=scan.nextLong();
	            if (n>0)
	            {
	                 System.out.println(Kaprekar(n)?"N�o":"Sim");
	            }
	        } while (n>0);
	        
	    }
	}

