import java.util.Scanner;

import javax.swing.JOptionPane;
import java.util.Arrays;

import java.util.HashMap;


public class Moda {
	public static void main(String[] args) {
		
	
	
		    Scanner ler = new Scanner(System.in);
		 
		    // tamanho do vetor
		  //http://www.devmedia.com.br/estatistica-descritiva-em-java/6160
		//int maximaVecesQueSeRepite = 0;
		//int moda = 0;
		//int n ;
		//System.out.print("Tamanho do vetor:");
		//n = ler.nextInt();
		//int M[] =  new int [n];
		
		//for(int i=0; i<M.length; i++){
		//	System.out.println("Preencha o vetor:");
			//M[i]=ler.nextInt();
	//	}
		
		}
	
}
		
