package DAO;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import Classes.Categoria;
import Classes.Film;
import Classes.Usuario;
import util.JPAUtil;

public class UsuarioDAO {
	
	//create and update
			public void salvar(Usuario usuario){
				EntityManager em = new JPAUtil().getEntityManager();
				em.getTransaction().begin();
				em.persist(usuario);
				em.getTransaction().commit();
				em.close();
			}
			//delete
			public void remover(Usuario usuario){
				EntityManager em = new JPAUtil().getEntityManager();
				em.getTransaction().begin();
				em.remove(usuario);
				em.getTransaction().commit();
				em.close();
			}
			//read
			public List<Usuario> listar(){
				EntityManager em = new JPAUtil().getEntityManager();
				em.getTransaction().begin();
				
				String jpql = "select u from Usuario u";
				javax.persistence.Query query = em.createQuery(jpql);
				List<Usuario> usuarios = query.getResultList();
				
				em.getTransaction().commit();
				em.close();
				return usuarios;
			}
			
			public Usuario buscarPorId(int id){
				EntityManager em = new JPAUtil().getEntityManager();
				em.getTransaction().begin();
				Usuario resultado = em.find(Usuario.class, id);
				em.getTransaction().commit();
				em.close();
				return resultado;
				
			}
			public Usuario buscaPorNome(String nome){
				EntityManager em = new JPAUtil().getEntityManager();
				
				String jpql = "select u from Usuario u where u.nome = :pnome";
				
				Query query = em.createQuery(jpql);
				String pnome = "%"+ nome +"%";
				query.setParameter("pnome", pnome);
				
				List<Usuario> usuarios = query.getResultList();
				Usuario user = usuarios.get(0);
				em.close();
				return user;
			}
			
			public void addFavorito(Usuario usuario, Film film){
				List<Film> filmes_favoritos = usuario.getFavoritos();
				
				filmes_favoritos.add(film);
				
				this.salvar(usuario);
			}
			
			public void removerFavorito(Usuario usuario, Film film){
				List<Film> fimes_favoritos = usuario.getFavoritos();
				
				fimes_favoritos.remove(film);
				
				this.salvar(usuario);
			}
			


}
