package DAO;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import Classes.Categoria;
import Classes.Film;
import util.JPAUtil;

public class CategoriaDAO {
	
	//create and update
		public void salvar(Categoria categoria){
			EntityManager em = new JPAUtil().getEntityManager();
			em.getTransaction().begin();
			em.persist(categoria);
			em.getTransaction().commit();
			em.close();
		}
		//delete
		public void remover(Categoria categoria){
			EntityManager em = new JPAUtil().getEntityManager();
			em.getTransaction().begin();
			em.remove(categoria);
			em.getTransaction().commit();
			em.close();
		}
		//read
		public List<Categoria> listar(){
			EntityManager em = new JPAUtil().getEntityManager();
			em.getTransaction().begin();
			
			String jpql = "select c from Categoria c";
			javax.persistence.Query query = em.createQuery(jpql);
			List<Categoria> categorias = query.getResultList();
			
			em.getTransaction().commit();
			em.close();
			return categorias;
		}
		
		public Categoria buscarPorId(int id){
			EntityManager em = new JPAUtil().getEntityManager();
			em.getTransaction().begin();
			Categoria resultado = em.find(Categoria.class, id);
			em.getTransaction().commit();
			em.close();
			return resultado;
			
		}
		public Categoria buscaPorNome(String nome){
			EntityManager em = new JPAUtil().getEntityManager();
			
			String jpql = "select c from Categoria c where c.nome = :pnome";
			
			Query query = em.createQuery(jpql);
			String pnome = "%"+ nome +"%";
			query.setParameter("pnome", pnome);
			
			List<Categoria> categorias = query.getResultList();
			Categoria cat = categorias.get(0);
			em.close();
			return cat;
		}
		

}
