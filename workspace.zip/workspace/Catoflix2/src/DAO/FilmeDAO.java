package DAO;

import java.util.List;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import Classes.Categoria;
import Classes.Film;
import util.DuracaoAno;
import util.JPAUtil;

public class FilmeDAO {
	
	//create and update
	public void salvar(Film film){
		EntityManager em = new JPAUtil().getEntityManager();
		em.getTransaction().begin();
		em.persist(film);
		em.getTransaction().commit();
		em.close();
	}
	
	//delete
	public void remover(Film film){
		EntityManager em = new JPAUtil().getEntityManager();
		em.getTransaction().begin();
		em.remove(film);
		em.getTransaction().commit();
		em.close();
	}
	
	//read
	public List<Film> listar(){
		EntityManager em = new JPAUtil().getEntityManager();
		em.getTransaction().begin();
		
		String jpql = "select f from Film f";
		javax.persistence.Query query = em.createQuery(jpql);
		List<Film> films = query.getResultList();
		
		em.getTransaction().commit();
		em.close();
		return films;
	}
	public List<Film> listarOrdemAlfa(){
		EntityManager em = new JPAUtil().getEntityManager();
		
		String jpql = 
				"select f from Film f order by f.titulo = :ptitulo";
		javax.persistence.Query query = em.createQuery(jpql);
		List<Film> films = query.getResultList();
		//query.setParameter(":ptitulo", titulo);
		em.close();
		return films;
	}
	public List<Film> listarFilmesDuracaoMenorQue(int minutos){
		EntityManager em = new JPAUtil().getEntityManager();
		
		String jpql = "select f from Film f where f.duracao < :pminutos";
		
		javax.persistence.Query query = em.createQuery(jpql);
		query.setParameter(":pminutos", minutos);
		List<Film> films = query.getResultList();
		em.close();
		
		return films;
	}
	public List<Film> listarFilmPorNomeCategoria(String nome_categoria){
		Categoria cat =
				new CategoriaDAO().buscaPorNome(nome_categoria);
		EntityManager em = new JPAUtil().getEntityManager();
		
		String jpql = 
				"select f from Film f where f.categoria = :pcategoria";
		javax.persistence.Query query = em.createQuery(jpql);
		query.setParameter(":pcategoria", nome_categoria);
		List<Film> films = query.getResultList();
		em.clear();
		
		return films;
				
	}
	
	public List<DuracaoAno> listarMediaDuracaoPorAno(){
		
		String jpql = 
				"selec new utils.DuracaoAno"
				+"( avg(f.duracao), f.ano ) from Film f "
				+ "group by f.ano";
		
		EntityManager em = new JPAUtil().getEntityManager();
		
		TypedQuery<DuracaoAno> tquery =
				em.createQuery(jpql, DuracaoAno.class);
		
		List<DuracaoAno> resultado = tquery.getResultList();
		
		
		return resultado;
	}

}
