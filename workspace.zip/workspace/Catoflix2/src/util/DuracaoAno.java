package util;

public class DuracaoAno {
	
	private double duracao;
	private int ano;
	
	public DuracaoAno(){
		
	}

	public double getDuracao() {
		return duracao;
	}

	public void setDuracao(double duracao) {
		this.duracao = duracao;
	}

	public int getAno() {
		return ano;
	}

	public void setAno(int ano) {
		this.ano = ano;
	}

}
