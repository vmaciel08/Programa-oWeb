package Executar;

import java.util.List;

import Classes.Categoria;
import Classes.Film;
import DAO.CategoriaDAO;

public class Teste02 {
	
	public static void main(String[] args) {
		
		Categoria cat = new Categoria();
		Categoria cat1 = new Categoria();
		Categoria cat2 = new Categoria();
		
		cat.setNome("Drama");
		cat1.setNome("Terror");
		cat2.setNome("Com�dia");
		
		
		CategoriaDAO categoriaDAO = new CategoriaDAO();
		Categoria cat5= categoriaDAO.buscarPorId(2);
		
		//CategoriaDAO categoriaDAO = new CategoriaDAO();
		//categoriaDAO.salvar(cat);
		List<Categoria> categorias = categoriaDAO.listar();
		
		for (Categoria categoria : categorias) {
			System.out.println(categorias.toString());
		}
		
		Film fm1 = new Film();
		fm1.setTitle("As branquelas");
		fm1.setDescricao("Bom pra porra!");
		
	}
	
}
