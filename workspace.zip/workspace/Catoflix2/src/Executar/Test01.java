package Executar;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import Classes.Film;


public class Test01 {
	public static void main(String[] args) {
		Film f1 = new Film();
		f1.setTitle("titanic");
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("catoflix2");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		em.persist(f1);
		em.getTransaction().commit();
		em.close();
		emf.close();
		
		
	}

}
