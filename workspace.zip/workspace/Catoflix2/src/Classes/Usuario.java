package Classes;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Usuario {
	
	@Id @GeneratedValue
	private int id;
	private String nome;
	private String password;
	private String email;
	
	@ManyToMany
	private List<Film> favoritos;
	private List<Categoria> categoria;
	
	public List<Film> getFavoritos() {
		return favoritos;
	}
	public void setFavoritos(List<Film> favoritos) {
		this.favoritos = favoritos;
	}
	public List<Categoria> getCategoria() {
		return categoria;
	}
	public void setCategoria(List<Categoria> categoria) {
		this.categoria = categoria;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	private String gender;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	@Override
	public String toString() {
		String res = "nome"+this.nome+ "gender" + this.gender+ "email"+ this.email;
		return res;
	}

}
