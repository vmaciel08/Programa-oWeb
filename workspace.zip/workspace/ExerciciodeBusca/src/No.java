
public class No {
	private int[] obj;
	
	//boolean visitado = false;
	boolean no_pai = false;
	public int [] objetivo = {1,2,3,4,5,6,7,8,0};
	
	public No(int[] objt){
		
	this.obj =	objt;
		
	}
	
	public int [] getObjetivo(){
		return objetivo;
	}
	public void setObjetivo (){
		this.obj = objetivo;
	}
}
