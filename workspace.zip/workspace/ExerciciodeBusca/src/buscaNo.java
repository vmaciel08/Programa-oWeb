import java.util.ArrayList;
import java.util.List;

public class buscaNo {
	public No no_inicial;
	
	boolean achou = false;
	public List <No> lista_adjacencia= new ArrayList<>() ;

	public void percurso(){
		
	}
	
	public int [] filho_Esquerdo(){
		
		
		No filho = new No (objt);
		return null;
		
	}
	
	public int [] filho_Direito(){
		return null;
	}
	
	public int [] filho_Meio(){
		return null;
	}
}
