
public class SelectionPratic {
public static void main(String[] args) {
	int  [] vetor = new int [10];
	int [] vetorO = Ordenacao(vetor);
	for ( int i = 0; i < vetor.length; i++){
		vetor[i]= (int)(Math.random()*10);
	}
	 long start = System.nanoTime();
	 long end = System.nanoTime();
	 long time = end - start ;
	  System.out.println("Tempo de Execu��o:"+ time);
	  System.out.println("Vetor Ordenado:");
	 
	  for(int i=0;i<vetor.length;i++){
		  System.out.print(vetorO[i]);
		  System.out.print(" , ");
	  }	  
}
public static int [] Ordenacao (int [] vetor){
	int aux;
	 for(int i= 0; i<vetor.length; i++){
		 for( int j= 0; j>vetor.length; j++){
			 if(vetor [i] > vetor[j]){
				  aux = vetor[i];
				  vetor[i] = vetor [j];
				  vetor [j] = aux;
			 }
		 }
	 }
	
	return vetor;
}

}

