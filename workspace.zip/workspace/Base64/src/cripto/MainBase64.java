package cripto;
import java.lang.reflect.Array;
import java.util.Arrays;

import javax.swing.JOptionPane;

import org.apache.commons.codec.binary.Base64;;
public class MainBase64 {

		public static void main(String[] args) {
			
			// string para criptografia
			String n = JOptionPane.showInputDialog("Digite uma palavra:");
			String helloword = n;
			
			//criptografando... � necess�rio usar o getbytes para criptografar
			 
			helloword = Base64.encodeBase64String(helloword.getBytes());
			
			System.out.println("Criptografado:"+ helloword);
			
			//decriptografando...ser� lan�ado para um vetor de bytes
			byte[] decoded = Base64.decodeBase64(helloword);
			
			// imprimindo o valor de cada posi��o no vetor
			System.out.println(Arrays.toString(decoded));
			
			
			String stringdecoded = new String(decoded);
			
			//imprimindo descriptografado
			 System.out.println("Descriptografando: "+stringdecoded);
			
		}
}
