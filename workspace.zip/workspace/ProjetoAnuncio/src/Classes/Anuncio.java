package Classes;

import java.sql.Timestamp;

public class Anuncio {
	
	public Anuncio(int id,String titulo, String descricao, String valor,
			String categoria, Timestamp criado_em, String contato, String cidade, String estado ) {
		super();
		this.id = id;
		this.titulo = titulo;
		this.descricao = descricao;
		this.valor = valor;
		this.categoria = categoria;
		this.criado_em = criado_em;
		this.contato = contato;
		this.cidade = cidade;
		this.estado = estado;
	}
		public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public String getValor() {
		return valor;
	}
	public void setValor(String valor) {
		this.valor = valor;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	public String getContato() {
		return contato;
	}
	public void setContato(String contato) {
		this.contato = contato;
	}
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public Timestamp getCriado_em() {
		return criado_em;
	}
	public void setCriado_em(Timestamp criado_em) {
		this.criado_em = criado_em;
	}
		private int id;
		private String titulo;
		private String descricao;
		private String valor;
		private String categoria;
		private String contato;
		private String cidade;
		private String estado;
		private Timestamp criado_em;
		
		
		
		
	
}
