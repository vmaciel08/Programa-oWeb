package DAO;
import java.sql.Connection;
import java.sql.Date;
import java.sql.Timestamp;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Calendar;

import Classes.Anuncio;
import Factory.ConnectionFactory;
public class AnuncioDAO {
	
	ConnectionFactory cf = new ConnectionFactory();
		
		public void inserirAnuncio(int id,String titulo, String descricao, String valor,
				String categoria, String contato, String cidade, String estado, Timestamp criado_em  ) throws SQLException {
			
			Connection con = cf.getConnection();
					
			String query = "insert into anuncios"
					+ " (nome, titulo, descricao,valor,categoria,contato,cidade,estado)"
					+ " values (?,?,?)";
			
			PreparedStatement stmt = 
					con.prepareStatement(query);
			
			stmt.setString(1, titulo);
			stmt.setString(2, descricao);
			stmt.setString(3, valor);
			stmt.setString(4, categoria);
			stmt.setString(5, contato);
			stmt.setString(6, cidade);
			stmt.setString(7,estado);
			
			Timestamp dt = 
				new Timestamp(Calendar.getInstance().getTimeInMillis());
			stmt.setTimestamp(3, dt);
			
			stmt.execute();
			
			stmt.close();
			cf.closeConnection(con);
		}
		
		public ArrayList<Anuncio> listarAnuncios() throws SQLException{
		
			Connection con = cf.getConnection();
			
			String query = "select * from anuncios";
			
			PreparedStatement stmt = con.prepareStatement(query);
			
			ResultSet res = stmt.executeQuery();
			
			ArrayList<Anuncio> anuncios = new ArrayList<Anuncio>();
			
			while(res.next()) {
				int id = res.getInt("id");
				String nome = res.getString("nome");
				String titulo = res.getString("titulo");
				String descricao = res.getString("descricao");
				String valor = res.getString("valor");
				String categoria = res.getString("categoria");
				String contato = res.getString("contato");
				String cidade = res.getString("cidade");
				String estado = res.getString("estado");
				Timestamp criado_em = res.getTimestamp("criado_em");
				
				Anuncio anun = new Anuncio(id, titulo, descricao, valor, categoria, criado_em, contato, cidade, estado);
				anuncios.add(anun);
			}
			
			res.close(); 
			stmt.close();
			cf.closeConnection(con);

			return anuncios;
		}
	}


