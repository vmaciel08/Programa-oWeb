package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Classes.User;
import Factory.ConnectionFactory;

public class UserDAO {
	//CRUD: CREATE + READ + UPDATE + DELETE
	
	public void createUser(User user) throws SQLException{
		//estabelecer a conex�o com o BD
		ConnectionFactory cf = new ConnectionFactory();
		Connection con = cf.getConnection();
		
		//escrever a query de inser��o
		String query = "insert into users (name_users, "
				+ "email_users, password_users, "
				+ "gender_users, birthdate_users) "
				+ "values (?,?,?,?,?)";
		
		//Preparar a query
		PreparedStatement stmt = con.prepareStatement(query);
		
		stmt.setString(1, user.getName());
		stmt.setString(2, user.getEmail());
		stmt.setString(3,user.getPassword());
		stmt.setString(4, user.getGender());
		stmt.setDate(5, user.getBirthdate());
		//executar a query
		stmt.execute();
		
		//fecha a conex�o
		stmt.close();
	}
	
	public ArrayList<User> readUsers() throws SQLException{
		//estabelecer uma conexao com o DB
		ConnectionFactory cf = new ConnectionFactory();
		Connection con = cf.getConnection();
		//criar a query de consulta
		String query = "select *from users";
		//executar a query de consulta
		
		PreparedStatement stmt = con.prepareStatement(query);
		ResultSet res = stmt.executeQuery();
		
		//criar arrayList para retorno
		ArrayList<User> users = new ArrayList<User>();
		
		//Pegar o resultado e transformar em um arrayList
		while(res.next()){
			User us = new User();
			us.setId(res.getInt("id_users"));
			us.setName(res.getString("name_users"));
			us.setEmail(res.getString("email_users"));
			us.setPassword(res.getString("password_users"));
			us.setGender(res.getString("gender_users"));
			us.setBirthdate(res.getDate("birthdate_users"));
			
			users.add(us);
			
		}
		return users;
	}
	
	public void updateUser(User user) throws SQLException{
		//estabelecer a conex�o com o BD 
		ConnectionFactory cf = new ConnectionFactory();
		Connection con = cf.getConnection();
		//criar a query de altera��o
		String query = "update users "
						+ "set name_users = ?, " 
						+ "email_users = ?, "
						+"password_users = ?, "
						+"gender_users = ?, "
						+"birthdate_users = ? "
						+ "where id_users = ?";
		//preparar a query
		PreparedStatement stmt = con.prepareStatement(query);
		stmt.setString(1, user.getName());
		stmt.setString(2, user.getEmail());
		stmt.setString(3, user.getPassword());
		stmt.setString(4, user.getGender());
		stmt.setDate(5, user.getBirthdate());
		stmt.setInt(6, user.getId());
		//executar a query
		stmt.execute();
		//fim
	}
	
	public void deleteUser(User user) throws SQLException{
		//estabelexer conex�o
		ConnectionFactory cf = new ConnectionFactory();
		Connection con = cf.getConnection();
		
		//criar a query
		String query = "delete from users where id_users = ?";
		
		//preparar a query
		PreparedStatement stmt = con.prepareStatement(query);
		stmt.setInt(0, user.getId());
		
		//executar a query
		stmt.execute();
		
		
	}

}
