package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Classes.Category;
import Classes.Film;
import Factory.ConnectionFactory;

public class FilmDAO {

	public ArrayList<Film> readFilms() throws SQLException{
		//estabelexer conexao
		ConnectionFactory cf = new ConnectionFactory();
		Connection con = cf.getConnection();
		//criar query
		String query = "select *from films " 
						+ "join categories "
						+ "where films.id_category_films "
						+ "= categories.id_categories";
		//preparar query
		PreparedStatement stmt = con.prepareStatement(query);
		
		//executar query 
		ResultSet result = stmt.executeQuery();
		
		//criar arraylist de films
		ArrayList<Film> films = new ArrayList<Film>();
		
		//preencher array
		while(result.next()){
			Film f = new Film();
			Category cat = new Category();
			
			cat.setId(result.getInt("id_categories"));
			cat.setName(result.getString("name_categorires"));
			
			f.setId(result.getInt("id_films"));
			f.setCategory(cat);
			f.setTitle(result.getString("title_films"));
			f.setDescription(result.getString("description_films"));
			f.setDuration(result.getInt("duraturion_films"));
			f.setYear(result.getInt("year_films"));
			
			films.add(f);
		}
		//retornar os fimes
		
		return films;
	}
}
