package Executar;

import java.sql.SQLException;
import java.util.ArrayList;

import Classes.User;
import DAO.UserDAO;

public class TestUpdateUser {
	public static void main(String[] args) throws SQLException {
		UserDAO userdao = new UserDAO();
		
		ArrayList<User> users = userdao.readUsers();
		
		User us0 = users.get(0);
		
		us0.setName("Thomas");
		
		userdao.updateUser(us0);
	}

}
