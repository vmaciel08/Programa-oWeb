package Executar;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Date;
import java.text.SimpleDateFormat;

import Classes.User;
import DAO.UserDAO;

public class TestCreateUser {

		public static void main(String[] args) throws ParseException, SQLException {
			//criar objeto usuario
			User userTest = new User();
			//settar os valores desse usu�rio
			userTest.setName("Maria feij�o");
			userTest.setEmail("Mafeij@catoflix.com");
			userTest.setPassword("000");
			userTest.setGender("F");
			
			SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
			Date parsed = format.parse("19880802");
			java.sql.Date dt = new java.sql.Date(parsed.getTime());
			
			System.out.println(dt);
			
			userTest.setBirthdate(dt);
			
			UserDAO userdao = new UserDAO();
			
			userdao.createUser(userTest);
			
		}
}
