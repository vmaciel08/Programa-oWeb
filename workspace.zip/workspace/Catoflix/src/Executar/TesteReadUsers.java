package Executar;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import Classes.User;
import DAO.UserDAO;

public class TesteReadUsers {
	public static void main(String[] args) throws ParseException, SQLException {
		//criar objeto usuario
		
		
		
		
		UserDAO userdao = new UserDAO();
		
		ArrayList<User> users = userdao.readUsers();
		for (User user : users) {
			System.out.println(user);
			
		}
		
	}


}
