package Executar;

import java.sql.SQLException;
import java.util.ArrayList;

import Classes.Film;
import DAO.FilmDAO;

public class TestReadFilms {
	
	public static void main(String[] args) throws SQLException {
		FilmDAO fdao = new FilmDAO();
		
		ArrayList<Film> films = fdao.readFilms();
		
		for (Film film : films) {
			System.out.println(film);
			System.out.println("\n");
		}
	}

}
