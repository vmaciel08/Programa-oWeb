
public class InsertionPratic {
public static void main(String[] args) {
	int  [] vetor = new int [10];
	System.out.print("Vaca H:");
	for ( int i = 0; i < vetor.length; i++){
		vetor[i]=i;
		System.out.print(",");
		  System.out.print(vetor[i]);
	}
	
	 long start = System.nanoTime();
	 long end = System.nanoTime();
	 long time = end - start ;
	  System.out.println("Tempo de Execu��o:"+ time);
	  
}
public static int [] Ordenacao (int [] vetor){
	int aux;
	 for(int i= 0; i<vetor.length; i++){
		 for( int j= i; j>0; j--){
			 if(vetor [j] < vetor[j-1]){
				  aux = vetor[j];
				  vetor[j] = vetor [j-1];
				  vetor [j-1] = aux;
			 }
		 }
	 }
	
	return vetor;
}
}
