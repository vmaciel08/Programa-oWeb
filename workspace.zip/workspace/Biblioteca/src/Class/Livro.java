package Class;

public class Livro {
	
	private int id_livro;
	private String titulo;
	private int ano;
	
	public int getId_livro() {
		return id_livro;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public int getAno() {
		return ano;
	}
	public void setAno(int ano) {
		this.ano = ano;
	}
	public void setId_livro(int id_livro) {
		this.id_livro = id_livro;
	}
	
}
