package Class;

import java.sql.Date;
import java.util.ArrayList;

public class Aluguel {

	
	private int id_aluguel;
	private Aluno id_aluno;
	ArrayList<Livro> livros;
	public ArrayList<Livro> getLivros() {
		return livros;
	}
	public void setLivros(ArrayList<Livro> livros) {
		this.livros = livros;
	}
	private Date data_aluguel;
	private Date data_entrega;
	private String status;
	
	public int getId_aluguel() {
		return id_aluguel;
	}
	public void setId_aluguel(int id_aluguel) {
		this.id_aluguel = id_aluguel;
	}
	public Aluno getId_aluno() {
		return id_aluno;
	}
	public void setId_aluno(Aluno id_aluno) {
		this.id_aluno = id_aluno;
	}
	public Date getData_aluguel() {
		return data_aluguel;
	}
	public void setData_aluguel(Date data_aluguel) {
		this.data_aluguel = data_aluguel;
	}
	public Date getData_entrega() {
		return data_entrega;
	}
	public void setData_entrega(Date data_entrega) {
		this.data_entrega = data_entrega;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
