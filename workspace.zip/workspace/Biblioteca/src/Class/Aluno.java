package Class;


public class Aluno {
	
	public String toString() {
		String result = "Matricula: "+ this.matricula+
				"\nNome: "+this.nome;
		return result;
	}

	private int matricula;
	private String nome;
	
	private Aluno aluno;
	public Aluno getAluno() {
		return aluno;
	}
	public void setAluno(Aluno aluno) {
		this.aluno = aluno;
	}
	public int getMatricula() {
		return matricula;
	}
	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
}
