package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import Class.Autor;
import Factory.ConnectionFactory;

public class AutorDAO {
 
	public void inserirAutor(Autor autor) throws SQLException{
		ConnectionFactory conFac = new ConnectionFactory();
		Connection con = conFac.getConnection();
		String query = "insert into autor(id_autor, nome)"
				+"values (?,?)";
		
		PreparedStatement stmt = con.prepareStatement(query);
		stmt.setInt(1, autor.getId_autor());
		stmt.setString(2, autor.getNome_autor());
		
		stmt.execute();
		stmt.close();
	}
	
	
	public ArrayList<Autor> listarAutor() throws SQLException{
		ConnectionFactory cf = new ConnectionFactory();
		Connection con = cf.getConnection();
	//criar a query de consulta
	String query = "select *from autor";
	//executar a query de consulta
	
	PreparedStatement stmt = con.prepareStatement(query);
	ResultSet res = stmt.executeQuery();
	
	//criar arrayList para retorno
	ArrayList<Autor> autores = new ArrayList<Autor>();
	
	//Pegar o resultado e transformar em um arrayList
	while(res.next()){
		Autor au = new Autor();
		au.setId_autor(res.getInt("id_autor"));
		au.setNome_autor(res.getString("nome_autor"));
		
		
		autores.add(au);
		
	}
	return autores;
}
	
	
	public void editarAutor(Autor autor) throws SQLException{
		//estabelecer a conex�o com o BD 
		ConnectionFactory cf = new ConnectionFactory();
		Connection con = cf.getConnection();
		//criar a query de altera��o
		String query = "update autor "
						+ "set id_autor = ?, " 
						+ "nome = ?";
		//preparar a query
		PreparedStatement stmt = con.prepareStatement(query);
		stmt.setInt(1, autor.getId_autor());
		stmt.setString(2, autor.getNome_autor());
		//executar a query
		stmt.execute();
		//fim
	}
	

	
	public void deletarAutor(Autor autor) throws SQLException{
		//estabelexer conex�o
				ConnectionFactory cf = new ConnectionFactory();
				Connection con = cf.getConnection();
				
				//criar a query
				String query = "delete from autor where id_autor = ?";
				
				//preparar a query
				PreparedStatement stmt = con.prepareStatement(query);
				stmt.setInt(0, autor.getId_autor());
				
				//executar a query
				stmt.execute();
				
				
			}

		
	}
	

