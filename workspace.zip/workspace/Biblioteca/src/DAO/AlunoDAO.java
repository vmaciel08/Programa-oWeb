package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Class.Aluno;

import Factory.ConnectionFactory;

public class AlunoDAO {
	
	
	
	public void inserirAluno(Aluno aluno) throws SQLException{
		ConnectionFactory conFac = new ConnectionFactory();
		Connection con = conFac.getConnection();
		String query = "insert into Aluno(matricula, nome)"
				+"values (?,?)";
		
		PreparedStatement stmt = con.prepareStatement(query);
		stmt.setInt(1, aluno.getMatricula());
		stmt.setString(2, aluno.getNome());
		
		stmt.execute();
		stmt.close();
	}
	public ArrayList<Aluno> listarAluno() throws SQLException{
		ConnectionFactory cf = new ConnectionFactory();
		Connection con = cf.getConnection();
	//criar a query de consulta
	String query = "select *from aluno";
	//executar a query de consulta
	
	PreparedStatement stmt = con.prepareStatement(query);
	ResultSet res = stmt.executeQuery();
	
	//criar arrayList para retorno
	ArrayList<Aluno> alunos = new ArrayList<Aluno>();
	
	//Pegar o resultado e transformar em um arrayList
	while(res.next()){
		Aluno al = new Aluno();
		al.setMatricula(res.getInt("matricula"));
		al.setNome(res.getString("nome"));
		
		
		alunos.add(al);
		
	}
	return alunos;
}
	public void editarAluno( Aluno alunos) throws SQLException{
			//estabelecer a conex�o com o BD 
			ConnectionFactory cf = new ConnectionFactory();
			Connection con = cf.getConnection();
			//criar a query de altera��o
			String query = "update aluno "
							+ "set matricula = ?, " 
							+ "nome = ?";
			//preparar a query
			PreparedStatement stmt = con.prepareStatement(query);
			stmt.setInt(1, alunos.getMatricula());
			stmt.setString(2, alunos.getNome());
			//executar a query
			stmt.execute();
			//fim
		}
	
	
	public void deletar(Aluno alunos)throws SQLException{
			//estabelexer conex�o
			ConnectionFactory cf = new ConnectionFactory();
			Connection con = cf.getConnection();
			
			//criar a query
			String query = "delete from aluno where matricula = ?";
			
			//preparar a query
			PreparedStatement stmt = con.prepareStatement(query);
			stmt.setInt(0, alunos.getMatricula());
			
			//executar a query
			stmt.execute();
			
			
		}

	}
	
	
	
	
	
	
	
	

