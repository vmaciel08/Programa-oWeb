package DAO;

public class AluguelDAO {

}
