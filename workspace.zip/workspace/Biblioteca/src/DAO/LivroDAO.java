package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import Class.Livro;
import Factory.ConnectionFactory;

public class LivroDAO {
	
	public void inserirLivro(Livro livro) throws SQLException{
		ConnectionFactory conFac = new ConnectionFactory();
		Connection con = conFac.getConnection();
		String query = "insert into livro(titulo, ano)"
				+"values (?,?)";
		
		PreparedStatement stmt = con.prepareStatement(query);
		stmt.setString(2, livro.getTitulo());
		stmt.setInt(3, livro.getAno());
		
		stmt.execute();
		stmt.close();
	}
		
	
	public void editarLivro(Livro livro){
		//estabelecer a conex�o com o BD 
				ConnectionFactory cf = new ConnectionFactory();
				Connection con = cf.getConnection();
				//criar a query de altera��o
				String query = "update Autor "
								+ "set id_autor = ?, " 
								+ "nome = ?";
				//preparar a query
				PreparedStatement stmt = con.prepareStatement(query);
				stmt.setString(1, Livro.get());
				stmt.setString(2, Livro.getNome_autor());
				//executar a query
				stmt.execute();
				//fim
			}
			
		
	
	
	public void deletarLivro(){
		
	}

}
