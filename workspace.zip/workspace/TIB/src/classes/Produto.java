package classes;

import java.sql.Timestamp;



public class Produto {
	public Produto(int id, String nome, String preco, Timestamp criado_em) {
		super();
		this.id = id;
		this.nome = nome;
		this.preco = preco;
		this.criado_em = criado_em;
	}
	private int id;
	private String nome;
	private String preco;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getPreco() {
		return preco;
	}
	public void setPreco(String preco) {
		this.preco = preco;
	}
	public Timestamp getCriado_em() {
		return criado_em;
	}
	public void setCriado_em(Timestamp criado_em) {
		this.criado_em = criado_em;
	}
	private Timestamp criado_em;

		
	

}
