

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import DAO.ProdutoDAO;

public class Principal {

	public static void main(String[] args) throws SQLException {
		
		ProdutoDAO pdao = new ProdutoDAO();
		
//		pdao.inserirProduto("Mentos", "R$ 1,50");
		
		pdao.listarProdutos();
		
		//ArrayList<Produto> produto = pdao.
		
	}
}


