package DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.Timestamp;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Calendar;

import Factory.ConnectionFactory;
import classes.Produto;

public class ProdutoDAO {

	ConnectionFactory cf = new ConnectionFactory();
	
	public void inserirProduto(String nome, String preco) throws SQLException {
		
		Connection con = cf.getConnection();
				
		String query = "insert into produtos"
				+ " (nome, preco, criado_em)"
				+ " values (?,?,?)";
		
		PreparedStatement stmt = 
				con.prepareStatement(query);
		
		stmt.setString(1, nome);
		stmt.setString(2, preco);
		
		Timestamp dt = 
			new Timestamp(Calendar.getInstance().getTimeInMillis());
		stmt.setTimestamp(3, dt);
		
		stmt.execute();
		
		stmt.close();
		cf.closeConnection(con);
	}
	
	public ArrayList<Produto> listarProdutos() throws SQLException{
	
		Connection con = cf.getConnection();
		
		String query = "select * from produtos";
		
		PreparedStatement stmt = con.prepareStatement(query);
		
		ResultSet res = stmt.executeQuery();
		
		ArrayList<Produto> produtos = new ArrayList<Produto>();
		
		while(res.next()) {
			int id = res.getInt("id");
			String nome = res.getString("nome");
			String preco = res.getString("preco");
			Timestamp criado_em = res.getTimestamp("criado_em");
			
			Produto prod = new Produto(id,nome,preco,criado_em);
			produtos.add(prod);
		}
		
		res.close(); 
		stmt.close();
		cf.closeConnection(con);

		return produtos;
	}
}