import javax.swing.JOptionPane;

public class testeBuble {
	public static void main(String[] args) {
		int tamanho = Integer.parseInt(JOptionPane.showInputDialog("Digite o tamanho do vetor:"));
		int[] vet = new int [tamanho];
		for ( int i = 0; i < vet.length; i++){
			vet[i]= Integer.parseInt(JOptionPane.showInputDialog("Preencha o Vetor:"));
		}
		int aux = 0;
		int i = 0;
		
		System.out.print("Vetor desordenado: ");
		for(i = 0; i<vet.length; i++){
			System.out.print(" "+vet[i]);
		}
		System.out.println(" ");
		
		for(i = 0; i<vet.length; i++){
			for(int j = 0; j<tamanho; j++){
				if(vet[j] > vet[j + 1]){
					aux = vet[j];
					vet[j] = vet[j+1];
					vet[j+1] = aux;
				}
			}
		}
		System.out.print("Vetor organizado:");
		for(i = 0; i<vet.length; i++){
			JOptionPane.showMessageDialog(null,vet[i]);
			System.out.print(" "+vet[i]);
		}
		long start = System.nanoTime();
		 long end = System.nanoTime();
		 long time = end - start ;
		  System.out.print("Tempo de Execu��o:"+ time);
	}
}



