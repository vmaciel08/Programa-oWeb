
public class BubblePratic {
	public static void main(String[] args) {
		int[] vet = new int [10];
		for ( int i = 0; i < vet.length; i++){
			vet[i]= (int)(Math.random()*10);
		}
		int aux = 0;
		int i = 0;
		
		System.out.print("Vetor desordenado: ");
		for(i = 0; i<vet.length; i++){
			System.out.print(" "+vet[i]);
		}
		System.out.println(" ");
		
		for(i = 0; i<vet.length; i++){
			for(int j = 0; j<i; j++){
				if(vet[j] > vet[j + 1]){
					aux = vet[j];
					vet[j] = vet[j+1];
					vet[j+1] = aux;
				}
			}
		}
		System.out.print("Vetor organizado:");
		for(i = 0; i<vet.length; i++){
			System.out.print(" "+vet[i]);
		}
		long start = System.nanoTime();
		 long end = System.nanoTime();
		 long time = end - start ;
		  System.out.println("Tempo de Execu��o:"+ time);
	}
}
