
public class mergeSort {
	
public static void main(String[] args) {
	 
	int[] lista = new int[100];	//Criando vetor 
	
	 //Preenchendo o vetor criado com o tamanho da lista de numero desordenados
	 for(int i=0;i<lista.length;i++){
	
		 lista[i] = (int)(Math.random()*1000); //metodo Random gera numero aleatorios com sequencia at� o numero especificado 
	 
	 }
	 long start = System.nanoTime();
	 long end = System.nanoTime();
	 long time = end - start ;
	  System.out.println("Tempo de Execu��o:"+ time);
   	
	 	//Chamando o metodo sort
   	sort(lista, 0, lista.length);
		
   	//chama o metodo de imprimir e mostrar o vetor ordenado
   	imprimir(lista);
		
	
} 

//Metodo para listar o vetor ordenado
public static int[] imprimir(int a[]){
	for (int i = 0; i < a.length; i++) {
		System.out.print(a[i]+" ");
	}
	return a;
}

public static void sort(int[] a, int incio, int fim) 
{
   int N = fim - incio;         
   if (N <= 1){ 
       return;
   }
   
   int meio = incio + N/2; 
   // ordenacao recursiva 
   sort(a, incio, meio); 
   sort(a, meio, fim); 
   // merge os subvetores ordenados
   int[] temp = new int[N]; // vetor auxiliar 
   int i = incio, j = meio;
   
   for (int k = 0; k < N; k++) 
   {

       if (i == meio) { 
           temp[k] = a[j++];}
       else if (j == fim) {
           temp[k] = a[i++];}
       else if (a[j]<a[i]) {
           temp[k] = a[j++];}
       else {
           temp[k] = a[i++];}
   }    
   for (int k = 0; k < N; k++) { 
       a[incio + k] = temp[k];}         
}
 

}