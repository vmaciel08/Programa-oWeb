
public class Cs {
	public static void main(String[] args) {
		 int [] Desordenado = {2,3,1,1,2,3,3,2,1,0};
	      int [] Ordenado = ordenaContagem(Desordenado);
	      long start = System.nanoTime();
	 	 long end = System.nanoTime();
	 	 long time = end - start ;
	 	  System.out.println("Tempo de Execu��o:"+ time);
	 	  System.out.print("Vetor Ordenado:");
	      for(int i = 0; i<Ordenado.length;i++){
	    	  System.out.print("  "+Ordenado[i]+",");
	      }
	}
	
	  
    public static int [] ordenaContagem (int [] a ){
    int [] aux = new int [a.length];
    int min = 0;
    int max = 0;
     //procurando menor e maior dentro do vetor
    System.out.println("1� FOR");
    for (int i = 0; i < a.length; i++){
        if(a[i]<min){
        min = a[i];
    
    }else if(a[i] > max){
    max = a[i];
    }
   System.out.println((i+1)+" � Rodada:");
   System.out.println("Min:"+min+",Max:"+max);
    }
    int [] c = new int [max + 1];
    //contagem(quantas vezes se repetem um valor dentro de um indice de varia��o de elementos)
    System.out.println("2� FOR");
    for(int i = 0; i< a.length; i++){
        c[a[i]]++;
        System.out.println((i+1)+"� Rodada:");
        System.out.println("A[i]:"+a[i]+", C[a[i]]:"+c[a[i]]);
    } 
    c[0]--;
    //somatoria
    System.out.println("3� FOR");
    for(int i = 1; i<c.length; i++){
    	c[i]= c[i] + c[i-1];
    	System.out.println((i+1)+"� Rodada:");
    	System.out.println("C[i]="+c[i]);
    }
    System.out.println("4�FOR");
     for(int i =a.length-1;i>= 0;i--){
    	 aux [c[a[i]]--] = a[i];
    	 System.out.println((i+1)+"� Rodada:");
    	 System.out.println("Aux = "+ aux );
     }
    return aux;
    
    }


	}


