import java.util.Scanner;

import javax.swing.JOptionPane;

public class Merge {
	 public static void main(String[] args) {
		
	Scanner scan = new Scanner(System.in);
		 int tamanho = Integer.parseInt(JOptionPane.showInputDialog("Digite o tamanho do vetor:"));
			
			int  [] vetor = new int [tamanho];
			for(int i =0; i<tamanho; i++){
				vetor[i]= Integer.parseInt(JOptionPane.showInputDialog("Informe o elemento da posi��o"+" "+i+" do vetor:"));
			
				
			}
			
		 long start = System.nanoTime();
		 long end = System.nanoTime();
		 long time = end - start ;
		  JOptionPane.showMessageDialog(null, "Tempo de Execu��o:"+ time);
		  
		  
		 	//Chamando o metodo sort
	   	sort(vetor, 0, vetor.length);
			
	   	//chama o metodo de imprimir e mostrar o vetor ordenado
	   	imprimir(vetor);
			
		
	} 

	//Metodo para listar o vetor ordenado
	public static int[] imprimir(int a[]){
		
		for (int i = 0; i < a.length; i++) {
			
			  JOptionPane.showMessageDialog(null,"Vetor Ordenado:"+a[i]+" ");
			
		}
		return a;
	}

	public static void sort(int[] a, int incio, int fim) 
	{
	   int N = fim - incio;         
	   if (N <= 1){ 
	       return;
	   }
	   
	   int meio = incio + N/2; 
	   // ordenacao recursiva 
	   sort(a, incio, meio); 
	   sort(a, meio, fim); 
	   // merge os subvetores ordenados
	   int[] temp = new int[N]; // vetor auxiliar 
	   int i = incio, j = meio;
	   
	   for (int k = 0; k < N; k++) 
	   {

	       if (i == meio) { 
	           temp[k] = a[j++];}
	       else if (j == fim) {
	           temp[k] = a[i++];}
	       else if (a[j]<a[i]) {
	           temp[k] = a[j++];}
	       else {
	           temp[k] = a[i++];}
	   }    
	   for (int k = 0; k < N; k++) { 
	       a[incio + k] = temp[k];}         
	}
	 

	}

