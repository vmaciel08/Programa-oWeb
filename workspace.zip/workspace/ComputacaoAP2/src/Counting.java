import javax.swing.JOptionPane;

public class Counting {
public static void main(String[] args) {
	int tamanho = Integer.parseInt(JOptionPane.showInputDialog("Digite o tamanho do vetor:"));
	
	
	int[] desordenado = new int [tamanho];
	for(int i =0; i<tamanho; i++){
		desordenado[i]= Integer.parseInt(JOptionPane.showInputDialog("Informe o elemento da posi��o"+" "+i+" do vetor:"));
	}
		long start = System.nanoTime();
		int[] ordenado = ordenaContagem(desordenado);
		long end = System.nanoTime();
		long time = end-start;
		for (int i = 0; i < ordenado.length; i++) {
			 JOptionPane.showMessageDialog(null,"Vetor Ordenado"+ordenado[i]);
		}
		 JOptionPane.showMessageDialog(null,"Tempo de Execu��o:"+time);
	}
	
	public static int[] ordenaContagem(int[] a){
		
		int[] aux = new int[a.length];
		int min = 0;
	    int max = 0;
	    //procurando menor e maior dentro do vetor

		System.out.println("1� FOR");
		for (int i = 0; i < a.length; i++){
			if(a[i] < min){
				min = a[i]; 
			}else if (a[i] > max){
				max = a[i];
			}
			System.out.println((i+1)+"� Rodada:");
			System.out.println("Min: " + min + ", Max: " + max);
			
		}
		
		int[] c = new int[max+1];
		//contagem(quantas vezes se repetem um valor dentro de um indice de varia��o de elementos)
		System.out.println("2� FOR");
		for (int i = 0; i <a.length; i++){
			c[a[i]]++;
			System.out.println((i+1)+"� Rodada:");
			System.out.println("A[i]: " + a[i] + ", C[A[i]]: " + c[a[i]]);
		}
		 //somatoria
		c[0]--;
		for (int i = 1; i < c.length; i++){
			c[i] = c[i] + c[i-1]; 
		}
		
		for (int i = a.length-1; i >= 0; i--){
			aux[c[a[i]]--] = a[i];
		}
		
		
		return aux; 
	}

}













