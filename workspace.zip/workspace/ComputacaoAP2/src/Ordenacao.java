import javax.swing.JOptionPane;

public class Ordenacao {
	 int m;
	  public static int[] OrdenarInsertion(int[] vetor) {
	        int aux;
	        int c = 0;
	            for (int i = 1; i < vetor.length; i++) {
	                System.out.print("Rodada "+ c + " - ");
	                    for (int k = 0; k < vetor.length; k++) {
	                    System.out.print(" ");      
	                            System.out.print(vetor[k]);    
	                        }
	                     System.out.println(" ");
	                     c++;
	                for (int j = i; j > 0; j--) {
	                    if (vetor[j] < vetor[j-1]) {
	                    aux = vetor[j];
	                    vetor[j]= vetor[j-1];
	                    vetor[j-1] = aux;
	                    }
	                    System.out.print("Rodada "+ c + " - ");
	                    for (int k = 0; k < vetor.length; k++) {
	                    System.out.print(" ");      
	                            System.out.print(vetor[k]);    
	                        }
	                     System.out.println(" ");
	                     c++;
	                }
	            }
	            JOptionPane.showMessageDialog(null, "Ordenado com Insertion Sort em " +  (c - 1) + " Rodadas");
	        return vetor;     
	    }
	  
	    public static int[] Ordenarbubble(int[] vetor) {
	        int aux;
	        int c = 0;
	            for (int i = vetor.length; i > 1; i--) {
	                System.out.print("Rodada "+ c + " - ");
	                    for (int k = 0; k < vetor.length; k++) {
	                    System.out.print(" ");      
	                            System.out.print(vetor[k]);    
	                        }
	                     System.out.println(" ");
	                     c++;
	                for (int j = 1; j < i; j++) {
	                    if (vetor[j-1] > vetor[j]) {
	                        aux = vetor[j];
	                        vetor[j] = vetor[j-1];
	                        vetor[j-1] = aux;
	                    }
	                    System.out.print("Rodada "+ c + " - ");
	                    for (int k = 0; k < vetor.length; k++) {
	                    System.out.print(" ");      
	                            System.out.print(vetor[k]);    
	                        }
	                     System.out.println(" ");
	                     c++;
	                }          
	            }
	            JOptionPane.showMessageDialog(null, "Ordenado com Bubble Sort em " +  (c - 1) + " Rodadas");
	        return vetor;
	    }
	    
	    public static int[] Ordenarselection(int[] vetor) {
	        int c = 1;
	        for (int i = 0; i < vetor.length - 1; i++) {
	        int menor = i;
	            for (int j = menor + 1; j < vetor.length; j++) {
	                if (vetor[j] < vetor[menor]) {
	                menor = j;
	                }
	                System.out.print("Rodada - "+ c + " - ");
	                    for (int k = 0; k < vetor.length; k++) {
	                    System.out.print(" ");      
	                            System.out.print(vetor[k]);    
	                        }
	                     System.out.println(" ");
	                     c++;
	            }
	                if (menor != i) {
	                int t = vetor[i];
	                vetor[i] = vetor[menor];
	                vetor[menor] = t;
	                }
	                System.out.print("Rodada "+ c + " - ");
	                    for (int k = 0; k < vetor.length; k++) {
	                    System.out.print(" ");      
	                            System.out.print(vetor[k]);    
	                        }
	                     System.out.println(" ");
	                     c++;
	   
	         }
	        JOptionPane.showMessageDialog(null, "Ordenado com Selection Sort em " +  (c - 1) + " Rodadas");
	        return vetor;
	    }
	    
	    public static void Ordenarmerge(int[] a, int incio, int fim){
	        int c = 0;
	        Ordenacao o = new Ordenacao();
	        int N = fim - incio;         
	        if (N <= 1){ 
	            return;
	        }
	        
	        int meio = incio + N/2; 
	        
	        // ordenacao recursiva 
	        Ordenarmerge(a, incio, meio); 
	        c++;
	        Ordenarmerge(a, meio, fim); 
	        c++;
	        
	        int[] temp = new int[N];
	        int i = incio, j = meio;
	        
	        for (int k = 0; k < N; k++) 
	        {

	            if (i == meio) { 
	                temp[k] = a[j++];}
	            else if (j == fim) {
	                temp[k] = a[i++];}
	            else if (a[j]<a[i]) {
	                temp[k] = a[j++];}
	            else {
	                temp[k] = a[i++];}
	        }    
	        for (int k = 0; k < N; k++) { 
	            a[incio + k] = temp[k];}
	     
	    }
	    
	    public static int[] Ordenarcounting(int[] a){
			int c = 0;
			int[] aux = new int[a.length];
			int min = 0, max = 0;
			
			
			for (int i = 0; i < a.length; i++){
				if(a[i] < min){
					min = a[i]; 
	                      
				}else if (a[i] > max){
					max = a[i];
				}
			c++;	
			}
			
			int[] cou = new int[max+1];
			
			for (int i = 0; i <a.length; i++){
				cou[a[i]]++;
	                       c++;
			}
			
			cou[0]--;
			for (int i = 1; i < cou.length; i++){
				cou[i] = cou[i] + cou[i-1]; 
	                       c++;
			}
			
			for (int i = a.length-1; i >= 0; i--){
				aux[cou[a[i]]--] = a[i];                    
	                        c++;
			}
	                   System.out.print("Rodada "+ c + " - ");
	                    for (int z = 0; z < a.length; z++) {
	                    System.out.print(" ");      
	                            System.out.print(a[z]);    
	                        }
	                     System.out.println(" ");
	                        for (int i = 0; i < aux.length; i++) {
	            		JOptionPane.showMessageDialog(null, aux[i]);
	                        }
	                        JOptionPane.showMessageDialog(null, "Ordenado com Couting Sort em " +  (c - 1) + " Rodadas");
			return aux; 
	                
		}
	    

	    public void pesquisarNumero(int x, int [] vetor){
	        int cont;
	        for(cont = 0; cont < vetor.length; cont++){
	            if(vetor[cont] == x){
	                JOptionPane.showMessageDialog(null,"Encontrou o numero :  " + x + " na Posição " + cont );
	                break;
	            }
	        }
	        if(cont >= vetor.length)
	               JOptionPane.showMessageDialog(null,"Encontrou o número :  " + x + " Não foi encontrado ");
	    }
	    public  void Imprimir(int [] vetor){
	        for (int i = 0; i < vetor.length; i++) {
	            JOptionPane.showMessageDialog(null, vetor[i]);
	            
	        }
	    }
	    public  void tempo(long t){   
	            JOptionPane.showMessageDialog(null," Execultado em : "+t+ " ms" );
	    }
	    
	   
	}



