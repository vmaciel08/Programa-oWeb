import java.io.Console;
import java.util.Arrays;

import javax.swing.JOptionPane;

public class Computa��oMenuOrdenacao {
	public static int vetor[] = null;
	public static int vetorO[] = null;
	public static int rodadas;
	public static int Onde;
	public static int Busca;
	public static long start;
	public static long stop;
	public static long time;
	public static int tamanho;
	    
	public static void main(String[] args) {
	   
	     int opcao = 0;
	        
	while (opcao != 7) {
	         
	   opcao = Integer.parseInt(JOptionPane.showInputDialog("M�todos de Ordena��o"
	                    + "\n1.Ordenar com Insertion Sort"
	                    + "\n2.Ordenar com Bubble Sort"
	                    +"\n3. Ordenar com Selection Sort"
	                    +"\n4. Ordenar com o Merge Sort"
	                    +"\n5. Ordenar com o Countig Sort"
	                    + "\n6. Efetuar busca sequencial"));
	            
			switch (opcao) {
	                
	case 1:
		 vetor = PreencherVetor();
         vetorO = InsetionSort(vetor);
	     start = System.nanoTime();
	     stop = System.nanoTime();
	     time = stop - start;
	      Resultado();
	     break;
	                
	case 2:
		vetor = PreencherVetor();
		vetorO = BubbleSort(vetor);
		start = System.nanoTime();             
		stop = System.nanoTime();
	    time = stop - start;
	     Resultado();
	     break;
	           
	     case 3:
	     vetor = PreencherVetor();
	     vetorO = SelectionSort(vetor);
	     start = System.nanoTime();
	     stop = System.nanoTime();
	     time = stop - start;
	     Resultado();
	      break;
	      
	      case 4:
	    	  vetor = PreencherVetor();
	    	  OrdenaMerge(vetor, 0, tamanho - 1);
	    	  start = System.nanoTime();
	    	  stop = System.nanoTime();
	    	  time = stop - start;
	    	  Resultado();
	      break;
	               
	      case 5:
	    	  vetor = PreencherVetor();
	    	  vetorO = CountigSort(vetor);
	    	  start = System.nanoTime();
	    	  stop = System.nanoTime();
	    	  time = stop - start;
	    	  Resultado();
	      break;
	                
	      case 6:
	    	vetor = PreencherVetor();
	        BuscaSequencial(vetor);
	        start = System.nanoTime();               
	        stop = System.nanoTime();
	        time = stop - start;
	        Resultado();
	      break;
	               }
	       }
	  
	  }

	  
	  public static void Resultado() {
	        
	JOptionPane.showMessageDialog(null, "Vetor Inicial: " + Arrays.toString(vetor)
	            
	    + "\nVetor Ordenado: " + Arrays.toString(vetorO)
	    + "\nN�mero de rodadas: " + rodadas
	    + "\nO tempo de execu��o em nanotime �: "  + time
	    + "\nO valor"+" foi encontrado na posi��o "+ Onde);
	 
	               
	   
	 }

	    public static int[] PreencherVetor() {

	        tamanho = Integer.parseInt(JOptionPane.showInputDialog("Digite o tamanho do vetor:"));
	 
	       int aux[] = new int[tamanho];
	       
	 for (int i = 0; i < aux.length; i++) {

	            aux[i] = Integer.parseInt(JOptionPane.showInputDialog("Informe o elemento da posi��o"+i+" do vetor:"));
	   
	     }
	       
	 return aux;
	  
	  }

	    

	   
	 public static int[] InsetionSort(int[] vetor) {

	        rodadas = 0;
	       
	 int aux = 0;
	      
	  for (int i = 1; i < vetor.length; i++) {
	  
	          rodadas++;
	           
	 for (int j = i; j > 0; j--) {
	        
	        rodadas++;
	               
	 if (vetor[j] < vetor[j - 1]) {
	 
	                	          
	          aux = vetor[j];
	       
	             vetor[j] = vetor[j - 1];
	     
	               vetor[j - 1] = aux;
	     
	           }
	        
	    }
	      
	  }
	        
	return vetor;
	  
	  }
	    public static int[] BubbleSort(int[] vetor) {
	 
	       rodadas = 0;
	       int aux = 0;
	       for (int i = vetor.length; i > 1; i--) {
	    
	        rodadas++;
	        for (int k = 1; k < i; k++) {
	               
	 rodadas++;
	                             
	 if (vetor[k - 1] > vetor[k]) {


	                  
	   
	                 aux = vetor[k];
	 
	                   vetor[k] = vetor[k - 1];
	 
	                   vetor[k - 1] = aux;
	   
	             }
	           }
	     
	   }
	       
	 return vetor;
	  
	  }
	    
	  
	  public static int[] SelectionSort(int vetor[]) {
	   
	     rodadas = 0;
	       

	       
	 int aux;
	      
	  for (int i = 0; i < vetor.length; i++) {
	    
	        rodadas++;
	          
	  for (int j = 0; j < vetor.length; j++) {
	   
	             rodadas++;
	            
	    if (vetor[i] < vetor[j]) {
	         
	          
	             
	       aux = vetor[i];
	            
	        vetor[i] = vetor[j];
	          
	          vetor[j] = aux;
	             


	   }
	        
	    }
	       
	 }
	        
	return vetor;
	  
	  }

	
	 
	   public static void OrdenaMerge(int[] aux, int inicio, int fim) {

	 
	       int meio = 0;
	 
	   
	    if (inicio < fim && inicio >= 0 && fim < aux.length) {

	   
	         meio = (fim + inicio) / 2;
	    
	        OrdenaMerge(aux, inicio, meio);
	 
	           OrdenaMerge(aux, meio + 1, fim);
	    
	    }

	        
	aux = DividirMerge(aux, inicio, meio, fim);

	     
	   System.arraycopy(aux, 0, vetorO, 0, aux.length);

	  
	  }
	   
	 public static int[] DividirMerge(int[] aux, int inicio, int meio, int fim) {

	     
	   int[] auxiliar = new int[aux.length + 1];

	   
	     int i = inicio;
	      
	  int j = meio + 1;
	    
	    int k = inicio;

	      
	  for (int x = inicio; x <= fim; x++) {
	     
	       auxiliar[x] = aux[x];
	        }

	        while (i <= meio && j <= fim) {
	            if (auxiliar[i] < auxiliar[j]) {
	                aux[k] = auxiliar[i];
	                i++;
	            } else {
	                aux[k] = auxiliar[j];
	                j++;
	            }
	        }

	        while (i <= meio) {
	            aux[k] = auxiliar[i];
	            i++;
	            k++;
	        }

	        while (j <= fim) {
	            aux[k] = auxiliar[j];
	            j++;
	            k++;
	        }

	        return aux;
	    }
	
	    public static int[] CountigSort(int[] vetor) {
	        rodadas = 0;
	       

	        int[] aux = new int[vetor.length];
	        int min = 0, max = 0;

	        for (int i = 0; i < vetor.length; i++) {
	            rodadas++;
	            if (vetor[i] < min) {
	                min = vetor[i];
	            } else if (vetor[i] > max) {
	                max = vetor[i];
	            }

	        }

	        int[] c = new int[max + 1];
	        for (int i = 0; i < vetor.length; i++) {
	            c[vetor[i]]++;
	            rodadas++;
	        }

	        c[0]--;
	        for (int i = 1; i < c.length; i++) {
	            rodadas++;
	            c[i] = c[i] + c[i - 1];
	        }

	        for (int i = vetor.length - 1; i >= 0; i--) {
	            rodadas++;
	            aux[c[vetor[i]]--] = vetor[i];
	        }

	        return aux;
	    }
	    public static void BuscaSequencial(int[] vetor){
	        rodadas = 0;
	        Onde = 0;
	        Busca = 0;
	        boolean achou = false;
	        while (achou == false) {
	            int busca= Integer.parseInt(JOptionPane.showInputDialog("Digite o valor procurado:"));
	            	for (int i = 0; i < vetor.length; i++) {
	                rodadas++;
	                	if (busca == vetor[i]) {
	                		achou = true;
	                		Onde = i;                    
	                }
	            }
	        }
	    }
}