import java.util.Arrays;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class menu {
	 public static void menu(){
	        System.out.println("\tM�todos de Ordena��o");
	       
	        System.out.println("1. Ordenar com Insertion Sort");
	        System.out.println("2. Ordenar com Bubble Sort");
	        System.out.println("3. Ordenar com Selection Sort");
	        System.out.println("4. Ordenar com o Merge Sort");
	        System.out.println("5. Ordenar com o Counting Sort");
	        System.out.println("6. Efetuar busca sequencial");
	        
	        System.out.println("Op��o:");
	    }
	 public static int[] Insetion(int[] vetor) {
	    rodadas = 0;
	     int aux = 0;
		 for (int i = 1; i < vetor.length; i++) {
		  
		          rodadas++;
		           
		 for (int j = i; j > 0; j--) {
		        
		        rodadas++;
		               
		 if (vetor[j] < vetor[j - 1]) {
		 
		                	          
		          aux = vetor[j];
		       
		             vetor[j] = vetor[j - 1];
		     
		               vetor[j - 1] = aux;
		     
		           }
		        
		    }
		      
		  }
		        
		return vetor;
		  
		    
	    }
	    public static int [] Ordenacao (int [] vetor){
	    	int aux;
	    	 for(int i= 0; i<vetor.length; i++){
	    		 rodadas++;
	    		 for( int j= i; j>0; j--){
	    			 rodadas++;
	    			 if(vetor [j] < vetor[j-1]){
	    				  aux = vetor[j];
	    				  vetor[j] = vetor [j-1];
	    				  vetor [j-1] = aux;
	    			 }
	    		 }
	    		 
	    	 }
	    	
	    	return vetor;
	    }
	    

	    
	    
	    public static int[] BubbleSort(int[] vetor) {
	   	 
		       rodadas = 0;
		       int aux = 0;
		       for (int i = vetor.length; i > 1; i--) {
		    
		        rodadas++;
		        for (int k = 1; k < i; k++) {
		               
		 rodadas++;
		                             
		 if (vetor[k - 1] > vetor[k]) {


		                  
		   
		                 aux = vetor[k];
		 
		                   vetor[k] = vetor[k - 1];
		 
		                   vetor[k - 1] = aux;
		   
		             }
		           }
		     
		   }
		       
		 return vetor;
		  
		  }
		   

	    
	    
	    public static int[] Selection(int vetor[]) {
	 	   
		     rodadas = 0;
		       

		       
		 int aux;
		      
		  for (int i = 0; i < vetor.length; i++) {
		    
		        rodadas++;
		          
		  for (int j = 0; j < vetor.length; j++) {
		   
		             rodadas++;
		            
		    if (vetor[i] < vetor[j]) {
		         
		          
		             
		       aux = vetor[i];
		            
		        vetor[i] = vetor[j];
		          
		          vetor[j] = aux;
		             


		   }
		        
		    }
		       
		 }
		        
		return vetor;
		  
		  }


	    
	    
	    public static void merge(){
	    	rodadas = 0;
	        System.out.println("Voc� entrou no Merge Sort!");
	        Scanner scan = new Scanner(System.in);
	        int tamanho;
	        System.out.println("Digite o tamanho do vetor:");
	        tamanho = scan.nextInt();
	        int[] vetor = new int[tamanho];	//Criando vetor 
	      
	    	
	   	 //Preenchendo o vetor criado com o tamanho da lista de numero desordenados
	   	 for(int i=0;i<vetor.length;i++){
	   		 
	   	System.out.println("Informe o elemento da posi��o"+i+" do vetor:");
	   		 vetor[i] =scan.nextInt(); //metodo Random gera numero aleatorios com sequencia at� o numero especificado 
	   		rodadas++;
	   	 }
	   	 long start = System.nanoTime();
	   	 long end = System.nanoTime();
	   	 long time = end - start ;
	   	System.out.println("\nO tempo de execu��o em nanotime �: " +time);
	 	 System.out.println("N�mero de rodadas: " + rodadas);
	   	 	//Chamando o metodo sort
	      	sort(vetor, 0, vetor.length);
	   		
	      	//chama o metodo de imprimir e mostrar o vetor ordenado
	      	imprimir(vetor);
	   		
	   	
	   } 

	   //Metodo para listar o vetor ordenado
	   public static int[] imprimir(int a[]){
		   System.out.print("Vetor Ordenado:");
	   	for (int i = 0; i < a.length; i++) {
	   		rodadas++;
	   		System.out.print(a[i]+" ");
	   		System.out.print(",");
	   	}
	   	return a;
	   }

	   public static void sort(int[] a, int incio, int fim) 
	   {
	      int N = fim - incio;         
	      if (N <= 1){ 
	          return;
	      }
	      
	      int meio = incio + N/2; 
	      // ordenacao recursiva 
	      sort(a, incio, meio); 
	      sort(a, meio, fim); 
	      // merge os subvetores ordenados
	      int[] temp = new int[N]; // vetor auxiliar 
	      int i = incio, j = meio;
	      
	      for (int k = 0; k < N; k++) {
	    	  rodadas++;

	          if (i == meio) { 
	              temp[k] = a[j++];}
	          else if (j == fim) {
	              temp[k] = a[i++];}
	          else if (a[j]<a[i]) {
	              temp[k] = a[j++];}
	          else {
	              temp[k] = a[i++];}
	      }    
	      for (int k = 0; k < N; k++) { 
	    	  rodadas++;
	          a[incio + k] = temp[k];}         
	   }
	    
	   public static void Merge(int[] aux, int inicio, int fim) {

			 
	       int meio = 0;
	 
	   
	    if (inicio < fim && inicio >= 0 && fim < aux.length) {

	   
	         meio = (fim + inicio) / 2;
	    
	        Merge(aux, inicio, meio);
	 
	           Merge(aux, meio + 1, fim);
	    
	    }

	        
	aux = AuxMerge(aux, inicio, meio, fim);

	     
	   System.arraycopy(aux, 0, vetorO, 0, aux.length);

	  
	  }
	   
	 public static int[] AuxMerge(int[] aux, int inicio, int meio, int fim) {

	     
	   int[] auxiliar = new int[aux.length + 1];

	   
	     int i = inicio;
	      
	  int j = meio + 1;
	    
	    int k = inicio;

	      
	  for (int x = inicio; x <= fim; x++) {
	     
	       auxiliar[x] = aux[x];
	        }

	        while (i <= meio && j <= fim) {
	            if (auxiliar[i] < auxiliar[j]) {
	                aux[k] = auxiliar[i];
	                i++;
	            } else {
	                aux[k] = auxiliar[j];
	                j++;
	            }
	        }

	        while (i <= meio) {
	            aux[k] = auxiliar[i];
	            i++;
	            k++;
	        }

	        while (j <= fim) {
	            aux[k] = auxiliar[j];
	            j++;
	            k++;
	        }

	        return aux;
	    }
	
	   
	    
	 public static int[] Counting(int[] vetor) {
	        rodadas = 0;
	       

	        int[] aux = new int[vetor.length];
	        int min = 0, max = 0;

	        for (int i = 0; i < vetor.length; i++) {
	            rodadas++;
	            if (vetor[i] < min) {
	                min = vetor[i];
	            } else if (vetor[i] > max) {
	                max = vetor[i];
	            }

	        }

	        int[] c = new int[max + 1];
	        for (int i = 0; i < vetor.length; i++) {
	            c[vetor[i]]++;
	            rodadas++;
	        }

	        c[0]--;
	        for (int i = 1; i < c.length; i++) {
	            rodadas++;
	            c[i] = c[i] + c[i - 1];
	        }

	        for (int i = vetor.length - 1; i >= 0; i--) {
	            rodadas++;
	            aux[c[vetor[i]]--] = vetor[i];
	        }

	        return aux;
	    }
	
	    
	 public static void Busca(int[] vetor){
	        rodadas = 0;
	        Onde = 0;
	        Busca = 0;
	        boolean achou = false;
	        while (achou == false) {
	            int busca= Integer.parseInt(JOptionPane.showInputDialog("Digite o valor procurado:"));
	            	for (int i = 0; i < vetor.length; i++) {
	                rodadas++;
	                	if (busca == vetor[i]) {
	                		achou = true;
	                		Onde = i;                    
	                }
	            }
	        }
	    }

	
	 		public static int Onde;
			public static int Busca;
	    	public static int rodadas;
	    	public static long start;
	    	public static long stop;
	    	public static long time;
	    	public static int tamanho;
	    	    
	    	public static int vetor[] = null;
	    	//Vetor padr�o
	    	    
	    	public static int vetorO[] = null;
	    
	    	  public static int[] PreencherVetor() {
	    		 Scanner scan = new Scanner(System.in);
	    		  int tamanho;
	    		  System.out.println("Digite o tamanho do vetor:");
	  	       tamanho = scan.nextInt();
	  	 
	  	      int Vetor[] = new int[tamanho];
	  	       
	  	 for (int i = 0; i < Vetor.length; i++) {
	  		 System.out.println("Informe o elemento da posi��o"+i+" do vetor:");
	  	           Vetor[i] = scan.nextInt();
	  	   
	  	     }
	  	       
	  	 return Vetor;
	  	  
	  	  }
	    	 public static void Exibir(){
	    		System.out.println( "\nVetor Ordenado: " + Arrays.toString(vetorO));
	    		   System.out.println("\nN�mero de rodadas: " + rodadas);
	    		    System.out.println("\nO tempo de execu��o em nanotime �: "  + time );  
	    	 }

	    
	    public static void main(String[] args) {
	        int opcao;
	        Scanner entrada = new Scanner(System.in);
	        
	        do{
	            menu();
	            opcao = entrada.nextInt();
	            
	            switch(opcao){
	            case 1:
	            
	                vetor = PreencherVetor();
	                vetorO = Insetion(vetor);
	                start = System.nanoTime();
	       	     	stop = System.nanoTime();
	       	     	time = stop - start;
	                Exibir();
	            case 2:
	            	 vetor = PreencherVetor();
		                vetorO = BubbleSort(vetor);
		                start = System.nanoTime();
		       	     	stop = System.nanoTime();
		       	     	time = stop - start;
		                Exibir();
	                break;
	                
	            case 3:
	            	 vetor = PreencherVetor();
		                vetorO = Selection(vetor);
		                start = System.nanoTime();
		       	     	stop = System.nanoTime();
		       	     	time = stop - start;
		                Exibir();
	                break;
	                
	            case 4:
	            	vetor = PreencherVetor();
	  	    	  Merge(vetor, 0, tamanho - 1);
	  	    	  start = System.nanoTime();
	  	    	  stop = System.nanoTime();
	  	    	  time = stop - start;
	  	    	  Exibir();

	                break;
	            
	            case 5:
	            	 vetor = PreencherVetor();
		                vetorO = Counting(vetor);
		                start = System.nanoTime();
		       	     	stop = System.nanoTime();
		       	     	time = stop - start;
		                Exibir();
	            	
	            case 6:
	            	vetor = PreencherVetor();
	    	        Busca(vetor);
	    	        start = System.nanoTime();               
	    	        stop = System.nanoTime();
	    	        time = stop - start;
	    	        Exibir();
	            	
	           
	            	
	            default:
	                System.out.println("Op��o inv�lida.");
	            }
	        } while(opcao != 6);
	    }
	

}

