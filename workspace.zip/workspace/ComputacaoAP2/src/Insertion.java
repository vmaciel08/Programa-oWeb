

import javax.swing.JOptionPane;

public class Insertion {
	public static void main(String[] args) {
		
		int tamanho = Integer.parseInt(JOptionPane.showInputDialog("Digite o tamanho do vetor:")) ;
		
		int  [] vetor = new int [tamanho];
		for(int i =0; i<tamanho; i++){
			vetor[i]= Integer.parseInt(JOptionPane.showInputDialog("Informe o elemento da posi��o"+" "+i+" do vetor:"));
			
			
		}
		
		
		 long start = System.nanoTime();
		 int [] vetorO =Ordenacao(vetor);
		 long end = System.nanoTime();
		 long time = end - start ;
		 JOptionPane.showMessageDialog(null,"Tempo de Execu��o:"+ time);
		  
		  for(int i=0;i<vetor.length;i++){
			  JOptionPane.showMessageDialog(null,"Vetor Ordenado:"+vetorO[i]);
		  }
		
		
	}
	public static int [] Ordenacao (int [] vetor){
		int aux;
	
		 for(int i= 0; i<vetor.length; i++){
			 for( int j= i; j>0; j--){
				 if(vetor [j] < vetor[j-1]){
					  aux = vetor[j];
					  vetor[j] = vetor [j-1];
					  vetor [j-1] = aux;
				 }
			 }
			
			 System.out.println((i+1)+"� Rodada Vetor:");
			 System.out.println("Vetor[i]"+vetor[i]);
		 }
		 
		return vetor;
	}
	}


