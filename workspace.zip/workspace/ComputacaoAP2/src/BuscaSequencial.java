import java.util.Scanner;

import javax.swing.JOptionPane;

public class BuscaSequencial {
	public static void main(String[] args) {

		int [] vetor = new int [10];
		
		int qual = Integer.parseInt(JOptionPane.showInputDialog("Digite o valor procurado:"));
		int onde = - 1;
		boolean achou = false;
		for (int i =0; i< vetor.length;i++){
			vetor[i] = i;
		}
			
			
			
		for(int i = 0; i< vetor.length; i++){
		if(vetor[i]==qual){
			achou = true;
			onde =i;
		}	
		}
		for(int i =0; i< vetor.length; i++){
			System.out.print(vetor[i]);
			System.out.print(" , ");
		}
		if (achou == true && onde > -1){
			System.out.println("O valor"+qual+" foi encontrado na posi��o "+ onde);
		}else{
			System.out.println("O valor"+ qual+ "n�o foi encontrado");
		}
		long start = System.nanoTime();
		
		long end = System.nanoTime();
		long time = end-start;
		System.out.println("Tempo de execu��o:"+ time);
		
	}
}
