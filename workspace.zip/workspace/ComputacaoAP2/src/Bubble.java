import java.util.Scanner;

import javax.swing.JOptionPane;

public class Bubble {
	public static void main(String[] args) {
int tamanho = Integer.parseInt(JOptionPane.showInputDialog("Digite o tamanho do vetor:")) ;
		
		int  [] vetor = new int [tamanho];
		for(int i =0; i<tamanho; i++){
			vetor[i]= Integer.parseInt(JOptionPane.showInputDialog("Informe o elemento da posi��o"+" "+i+" do vetor:"));
			
			
		}
		
		int aux = 0;
		int i = 0;
		
		

			
		
		for(i = 0; i<vetor.length; i++){
			for(int j = 0; j<vetor.length; j++){
				if(vetor[j] > vetor[j + 1]){
					aux = vetor[j];
					vetor[j] = vetor[j+1];
					vetor[j+1] = aux;
					
				}
				
			}
			
		}
		System.out.print("Vetor organizado:");
		for(i = 0; i<vetor.length; i++){
			JOptionPane.showMessageDialog(null,vetor[i]);
			System.out.print(" "+vetor[i]);
		}
		
		long start = System.nanoTime();
		 long end = System.nanoTime();
		 long time = end - start ;
		  JOptionPane.showMessageDialog(null,"Tempo de Execu��o:"+ time);
	}


}
